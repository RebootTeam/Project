package rebootServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Am.AmDAO;
import Am.AmDTO;

@WebServlet("/rebootServlet/OtpView.do")
public class OtpViewPageController extends HttpServlet{
	
	public OtpViewPageController() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		
		AmDAO dao = new AmDAO();
		AmDTO dto = new AmDTO();
		dto = dao.getAmMember(id);
		
		req.setAttribute("dto", dto);
		req.getRequestDispatcher("../otp/OtpViewPage").forward(req, resp);
		
	}
}
