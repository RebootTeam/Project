package Am;

import java.sql.Date;
import java.sql.Timestamp;

import common.JDBConnPool;
import profile.ProfileDTO;

public class AmDAO extends JDBConnPool {

	public AmDAO() {
		super();
	}

	//am2의 필요값과 info에서의 필요값을 빼서 am에 저장하는 과정 -> Otpview 생성위해서 
	public int insertDB(AmDTO dto) {
		int res = 0;
			String sql = "INSERT INTO AM (ID, DEPTN, NAME, GRADE, TYPE, DAY_T, A2.TIME_S, A2.TIME_E "
					+ "SELECT IFO.ID, IFO.DEPTN, IFO.NAME, IFO.GRADE, A2.TYPE, A2.DAY_T, A2.TIME_S, A2.TIME_E "
					+ "FROM INFO IFO, AM2 A2 WHERE IFO.ID = A2.ID";
		try {
			psmt=con.prepareStatement(sql);
			psmt.setString(1, dto.getId());
			psmt.setInt(2, dto.getDeptn());
			psmt.setString(3, dto.getName());
			psmt.setInt(4, dto.getGrade());
			psmt.setInt(5, dto.getType());
			psmt.setString(6, dto.getDay_t());
			psmt.setString(7, dto.getTime_s());
			psmt.setString(7, dto.getTime_e());
			res=psmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	
	public AmDTO getAmMember(String id) {
		AmDTO pdto = new AmDTO();
		String SQL = "SELECT * FROM AM WHERE id = ?";
		try {
			psmt = con.prepareStatement(SQL);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			if (rs.next()) {
				pdto.setId(rs.getString("id"));
				pdto.setDeptn(rs.getInt("deptn"));
				pdto.setName(rs.getString("name"));
				pdto.setGrade(rs.getInt("grade"));
				pdto.setType(rs.getInt("type"));
				pdto.setDay_t(rs.getString("day_t"));
				pdto.setTime_s(rs.getString("time_s"));
				pdto.setTime_e(rs.getString("time_e"));
			} 
		} catch (Exception e) {
			System.out.println("AmDAO GETAmMember에서 에러 발생");
			e.printStackTrace();
		} 	
		return pdto;       
	}
	

}
