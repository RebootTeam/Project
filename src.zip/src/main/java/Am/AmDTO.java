package Am;

import java.sql.Timestamp;
import java.util.Date;

import oracle.sql.DATE;

public class AmDTO {
	private String id;
	private int deptn;
	private String name;
	private int grade;
	private int type;
	private String day_t;
	private String time_s;
	private String time_e;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getDeptn() {
		return deptn;
	}
	public void setDeptn(int deptn) {
		this.deptn = deptn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getDay_t() {
		return day_t;
	}
	public void setDay_t(String day_t) {
		this.day_t = day_t;
	}
	public String getTime_s() {
		return time_s;
	}
	public void setTime_s(String time_s) {
		this.time_s = time_s;
	}
	public String getTime_e() {
		return time_e;
	}
	public void setTime_e(String time_e) {
		this.time_e = time_e;
	}
	
}
