package JOTP;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Am.AmDAO2;

@WebServlet("/otp/remove")
public class RemoveController extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 String id = (String) req.getSession().getAttribute("loginId");
		    
		    //DAO 생성
		    AmDAO2 dao = new AmDAO2();
//		    dao.deletePost(idx);
	}
}
