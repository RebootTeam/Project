package Am;

import java.sql.Timestamp;

public class AmDTO2 {
	private String id;
	private String type;
	private Timestamp time_;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Timestamp getTime_() {
		return time_;
	}

	public void setTime_(Timestamp time_) {
		this.time_ = time_;
	}

}
