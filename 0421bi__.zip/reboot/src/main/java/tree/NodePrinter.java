package tree;

public class NodePrinter {
    public static void printNode(Node node) {
        System.out.printf("%s[%s] %s (코드: %s, 상위코드: %s)%n",
                indent(node.level), node.level, node.name, node.code, node.parentCode);
        if (node.children != null) {
            for (Node child : node.children) {
                printNode(child);
            }
        }
    }

    private static String indent(int level) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < level - 1; i++) {
            sb.append("    ");
        }
        if (level > 1) {
            sb.append("└─ ");
        }
        return sb.toString();
    }
}