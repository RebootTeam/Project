package tree;

import java.util.List;

public class Node {
	public int level;
	public String name;
	public String code;
	public String parentCode;
	public List<Node> children;
}
