package tree;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import common.JDBConnPool;

public class TreeDAO extends JDBConnPool {
	// 기본생성자
	public TreeDAO() {
		super();
	}

	public void resetTree() {
		try {
			// TB_DEPT 테이블의 모든 데이터 삭제
			String deleteData = "DELETE FROM TB_DEPT";
			stmt = con.createStatement();
			stmt.executeUpdate(deleteData);

			// 기본값 삽입
			String initData = "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_001',NULL,'REBOOT');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_002','DE_001','1');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_003','DE_001','2');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_004','DE_001','3');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_005','DE_002','0');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_006','DE_002','1');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_007','DE_003','0');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_008','DE_003','1');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_009','DE_004','0');"
					+ "INSERT INTO TB_DEPT(DEPT_CD,PAR_DEPT_CD,DEPT_NM)VALUES('DE_010','DE_004','1')";
			stmt.executeUpdate(initData);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	public void insertTree() {
		try {
			String v_dept_cd = "DE_011";
			String v_dept_nm = "";

			String selectInfo = "SELECT DEPTN, NAME, GRADE FROM INFO";
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(selectInfo);

			while (rs.next()) {
				int deptn = rs.getInt("DEPTN");
				String name = rs.getString("NAME");
				int grade = rs.getInt("GRADE");

				if (deptn == 1 && grade == 0) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_005', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				} else if (deptn == 1 && grade == 1) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_006', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				} else if (deptn == 2 && grade == 0) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_007', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				} else if (deptn == 2 && grade == 1) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_008', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				} else if (deptn == 3 && grade == 0) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_009', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				} else if (deptn == 3 && grade == 1) {
					v_dept_nm = name;
					String insertData = "INSERT INTO TB_DEPT(DEPT_CD, PAR_DEPT_CD, DEPT_NM) " + "VALUES ('" + v_dept_cd
							+ "', 'DE_010', '" + v_dept_nm + "')";
					stmt.executeUpdate(insertData);
					v_dept_cd = "DE_" + String.format("%03d", Integer.parseInt(v_dept_cd.substring(3)) + 1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	public void getTree() {
		try {
			String query = "SELECT LEVEL, DEPT_NM, LPAD(' ', 2*LEVEL-1) || SYS_CONNECT_BY_PATH(DEPT_NM, '/') PATH, DEPT_CD, PAR_DEPT_CD "
					+ "FROM TB_DEPT " + "START WITH PAR_DEPT_CD IS NULL " + "CONNECT BY PAR_DEPT_CD = PRIOR DEPT_CD "
					+ "ORDER SIBLINGS BY DEPT_CD";
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				int level = rs.getInt("LEVEL");
				String deptName = rs.getString("DEPT_NM");
				String path = rs.getString("PATH");
				String deptCode = rs.getString("DEPT_CD");
				String parentDeptCode = rs.getString("PAR_DEPT_CD");

				System.out.printf("%s [%s] %s (코드: %s, 상위코드: %s)%n", path, level, deptName, deptCode, parentDeptCode);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}
}