package profile;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/rebootServlet/edit.do")
public class EditController extends HttpServlet {
    public EditController() {
        super();
    }

    protected void doget(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
    	String id = req.getParameter("id");
        ProfileDAO dao = new ProfileDAO();
        ProfileDTO pdto = dao.editMember(id);
        req.setAttribute("pdto", pdto);
        RequestDispatcher rd = req.getRequestDispatcher("../Reboot/MyPage.jsp");
        rd.forward(req, resp);
//        String pass = request.getParameter("pass");
//        String bday = request.getParameter("bday");
//        String pnum = request.getParameter("pnum");
//        String ad = request.getParameter("ad");
//
//        // db 연결
//        String url = "jdbc:oracle:thin:@localhost:1521:xe";
//        String dbId = "reboot";
//        String dbPw = "1234";
//
//        try {
//            Class.forName("oracle.jdbc.driver.OracleDriver");
//            conn = DriverManager.getConnection(url, dbId, dbPw);
//            System.out.println("Connected to the database");
//
//            // db 업데이트
//            String sql = "UPDATE INFO SET pass = ?, bday = ?, phone = ?, ad = ? WHERE id = ?";
//
//            PreparedStatement pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, pass);
//            pstmt.setString(2, bday);
//            pstmt.setString(3, pnum);
//            pstmt.setString(4, ad);
//            pstmt.setString(5, "id");
//            int result = pstmt.executeUpdate();
//            pstmt.close();
//            conn.close();
//            System.out.println(result + " rows updated");
//
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        //response.sendRedirect("Mypage.jsp"); // MyPage.jsp로 redirect
//        RequestDispatcher rd = request.getRequestDispatcher("../rebootServlet/myPage.do?id=${dto.id}");
    }
}
