package rebootServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import profile.ProfileDAO;
import profile.ProfileDTO;

@WebServlet("/rebootServlet/editPage.do")
public class EditPageController extends HttpServlet {
    public EditPageController() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	String id = req.getParameter("id");
    	
		ProfileDTO dto = new ProfileDTO();
		ProfileDAO pDao = new ProfileDAO();
		dto = pDao.editMember(id);

		req.setAttribute("dto", dto);
		req.getRequestDispatcher("/Reboot/EditPage.jsp").forward(req, resp);
    }
}