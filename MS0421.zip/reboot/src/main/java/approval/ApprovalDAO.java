package approval;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import common.JDBConnPool;

public class ApprovalDAO extends JDBConnPool {

	public int insertWrite(ApprovalDTO dto) {
		int result=0;
		String sql = "INSERT INTO APPROVAL(IDX,ID, NAME, DEPTN,TITLE, CONTENT, BOSS, REGDATE, OFILE,NFILE) VALUES(SEQ_APPROVAL_NUM.NEXTVAL,?,?,?,?,?,?,SYSDATE,?,?)";
	try {
		psmt = con.prepareStatement(sql);
		psmt.setString(1, dto.getId());
		psmt.setString(2, dto.getName());
		psmt.setInt(3, dto.getDeptn());
		psmt.setString(4, dto.getTitle());
		psmt.setString(5, dto.getContent());
		psmt.setString(6, dto.getBoss());
		psmt.setString(7, dto.getOfile());
		psmt.setString(8, dto.getNfile());

		result = psmt.executeUpdate();
	}catch(Exception e) {
		System.out.println("게시물 입력 중 예외");
		e.printStackTrace();
	}
	return result;
	
	}

	public int countAll(Map<String, Object> map) {
		int totalCount=0;
		
		String sql = "SELECT COUNT(*) FROM approval";
		if(map.get("searchStr")!=null) {
			sql += " where " +map.get("searchType")+" like '%"+map.get("searchStr")+"%'";
		}
		
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);	
			rs.next();	//ResultSet은 맨 처음은 빈	stmt = con.createStatement();	공간이기 때문에 한칸 넘기고 해야 함.
			totalCount = rs.getInt(1);
		}catch(Exception e) {
			System.out.println("게시물 카운트 중 에러");
			e.printStackTrace();
		}
		return totalCount;
	}

	public List<ApprovalDTO> getListPage(Map<String, Object> map, String id) {
		List<ApprovalDTO> bl = new Vector<>();
		

		
//		String sql = "SELECT * FROM APPROVAL";
//		
//		if(map.get("searchStr")!=null) {
//		    sql += " WHERE " +map.get("searchType")+" LIKE '%"+map.get("searchStr")+"%'";
//		    sql +=" AND DEPTN = (SELECT DEPTN FROM INFO WHERE ID = ?) ORDER BY NFILE DESC";
//		    
//		} else {
//		    sql +=" WHERE DEPTN = (SELECT DEPTN FROM INFO WHERE ID = ?) ORDER BY NFILE DESC";
//		}
		
		String sql = "SELECT ROWNUM AS PNUM, S.* FROM ( SELECT * FROM APPROVAL";
		
		if(map.get("searchStr")!=null) {
		    sql += " WHERE " +map.get("searchType")+" LIKE '%"+map.get("searchStr")+"%'";
		    sql +=" AND DEPTN = (SELECT DEPTN FROM INFO WHERE ID = ?) ORDER BY NFILE DESC) S";
		    sql +=" WHERE ROWNUM BETWEEN ? AND ?";
		    
		} else {
		    sql +=" WHERE DEPTN = (SELECT DEPTN FROM INFO WHERE ID = ?) ORDER BY NFILE DESC) S";
		    sql +=" WHERE ROWNUM BETWEEN ? AND ?";
		}
			
			try {
				psmt = con.prepareStatement(sql);
				psmt.setString(1, id);
				psmt.setString(2, map.get("start").toString());
				psmt.setString(3, map.get("end").toString());
				
				
				rs=psmt.executeQuery();
				while(rs.next()) {
					
					ApprovalDTO dto = new ApprovalDTO();
					
					dto.setIdx(rs.getString("idx"));
					dto.setId(rs.getString("id"));
					dto.setName(rs.getString("name"));
					dto.setTitle(rs.getString("title"));
					dto.setContent(rs.getString("content"));
					dto.setRegdate(rs.getDate("regdate"));
					dto.setOfile(rs.getString("ofile"));
					dto.setNfile(rs.getString("nfile"));
					dto.setState(rs.getString("state"));
					
					bl.add(dto);
				}
			}catch(Exception e) {
				System.out.println("게시물 목록 읽는 중 에러");
				e.printStackTrace();
			}
		
		return bl;
	}

	public ApprovalDTO getView(String idx) {
		ApprovalDTO dto = new ApprovalDTO();
		String sql="SELECT * FROM APPROVAL WHERE IDX=?";
		try {
			psmt = con.prepareStatement(sql);
			psmt.setString(1, idx);
			rs = psmt.executeQuery();
			if(rs.next()) {
				dto.setIdx(rs.getString("idx"));
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setRegdate(rs.getDate("regdate"));
				dto.setOfile(rs.getString("ofile"));
				dto.setNfile(rs.getString("nfile"));
				dto.setCompanion(rs.getString("companion"));

			}
		} catch (Exception e) {
			System.out.println("상세보기 중 예외");
			e.printStackTrace();
		}
				
		return dto;
	}
}
