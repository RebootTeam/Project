package profile;

import common.JDBConnPool;

public class ProfileDAO extends JDBConnPool{


	public ProfileDAO() {
		super();
	}

	public ProfileDTO getMember(String id) {
		ProfileDTO pdto = new ProfileDTO();
		String SQL = "SELECT * FROM INFO WHERE id = ?";
		try {
			psmt = con.prepareStatement(SQL);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			if (rs.next()) {
				pdto.setId(rs.getString("id"));
				pdto.setDeptn(rs.getInt("deptn"));
				pdto.setName(rs.getString("name"));
				pdto.setPassword(rs.getString("pass"));
				pdto.setAd(rs.getString("ad"));
				pdto.setPnum(rs.getInt("pnum"));
				pdto.setIn_d(rs.getDate("in_d"));
				pdto.setOut_d(rs.getDate("out_d"));
				pdto.setBday(rs.getDate("bday"));
				pdto.setGrade(rs.getInt("grade"));
			} 
		} catch (Exception e) {
			System.out.println("에러 발생");
			e.printStackTrace();
		} 
		
		return pdto;       
	}
}





   
   
   
   

